from peft import PeftModel
from transformers import AutoModelForCausalLM
from baseline import evaluate, save_predictions, score_predictions

model_path = 'pretrained_models/Qwen3-0.6B-Base'

model = AutoModelForCausalLM.from_pretrained(model_path, dtype='auto')
model = PeftModel.from_pretrained(
    model = model,
    model_id='model/qwen3_0p6b_lora/run04_random_n'
).to('cuda')

model.eval()

output_dir = 'outputs/qwen3_0p6b_lora/run04_random_n'

records = evaluate(model)
save_predictions(
    records,
    output_dir
)

report = score_predictions(
    records,
    output_dir
)

if report is not None:
    print('SoftCons:', report.soft_cons)
    print('HardCons:', report.hard_cons)