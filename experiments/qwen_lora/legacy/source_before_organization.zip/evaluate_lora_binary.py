import os
import sys
from pathlib import Path

import pandas as pd

script_dir = Path(__file__).resolve().parent
sys.path.insert(0, str(script_dir.parent.parent))

from binary_data_utils import evaluate_binary_with_scores

from evaluate_lora_pair import (
    load_lora_model,
    pair_aware_decode,
    score_methods
)


if __name__ == '__main__':
    os.chdir(script_dir)

    model_path = 'pretrained_models/Qwen3-0.6B-Base'

    adapter_path = (
        'model/'
        'qwen3_0p6b_binary/run01/C/best_adapter'
    )

    model = load_lora_model(model_path, adapter_path)

    records = evaluate_binary_with_scores(
        model,
        batch_size=16,
        split='dev'
    )

    df = pd.DataFrame(records)
    df = pair_aware_decode(df)

    output_dir = (
        script_dir / 'outputs/qwen3_0p6b_binary/run01/C'
    )
    output_dir.mkdir(parents=True, exist_ok=True)

    df.to_csv(
        output_dir / 'predictions_with_scores.csv',
        index=False,
        encoding='utf-8-sig'
    )

    print('保存样本数：', len(df))
    print('结果目录：', output_dir)

    score_methods(df, output_dir)